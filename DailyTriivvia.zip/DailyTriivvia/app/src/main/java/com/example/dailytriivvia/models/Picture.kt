package com.example.dailytriivvia.models

data class Picture(val imageUrl: String)